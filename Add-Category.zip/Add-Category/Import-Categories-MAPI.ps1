###########################################################################
#Created By: Vijayan Kumaran
#Date: 28th Dec 2016
#Purpose: This script can be executed locally in any machine installed with Outlook 2007 and PS v2 minimum to import Outlook Categories. Suitable for GPO
#         Update the variables before executing the script
#Usage: .\Import-Categories-MAPI.ps1
#Requirements: PowerShell 2.0 and Outlook 2007 at least
#Notes:
# - This script WILL NOT delete existing Outlook Categories
# - This script DOES NOT Backup existing Outlook Categories
###########################################################################

#***********Variables***********************
$Department = "HR"
$DIR = "C:\Temp\Outlook-Categories"
$Path = "$DIR\$Department-Categories.csv"
$Import = $True
#*******************************************

CD $DIR

# Prepare output collection
$return = @() 

$Outlook = New-Object -ComObject Outlook.Application
$Namespace = $Outlook.GetNamespace("MAPI")
$Categories = $Namespace.Categories

#Import Categories
If ($Import) 
{		
$InputCategories = Import-Csv -Path $Path -Delimiter ","
If ($InputCategories) 
{
ForEach ($InputCategory in $InputCategories) 
{
$Categories.Add($InputCategory.Name, $InputCategory.Color, $InputCategory.ShortCutKey) | Out-Null
Write-Host "Category '$($InputCategory.Name)' was imported."

Start-Sleep 7
}
Write-Host "Import completed."
} 
Else 
{
Write-Host "No Categories were imported. Input file was empty."
}
}
Else {
	#Export Categories
	If (Test-Path(Split-Path $Path -Parent)) {

		$Task = $Outlook.CreateItem("olTaskItem")
		#Show Outlook Categories to be exported
		$Task.ShowCategoriesDialog()
		
		If ($Task.Categories) {
			$TaskCategories = $Task.Categories -Split ",\s"
			ForEach ($TaskCategory in $TaskCategories) {
				$obj = "" | Select-Object Name, Color, ShortcutKey
				$obj.Name = $Categories.Item($TaskCategory).Name
				$obj.Color = [int]$Categories.Item($TaskCategory).Color
				$obj.ShortcutKey = [int]$Categories.Item($TaskCategory).ShortcutKey
				$return += $obj
			}
			$return | Export-Csv -Path $Path -Delimiter "," -Force -noTypeInformation -Encoding UTF8
			
			Write-Host "Selected Categories were exported to '$($Path)' file."
		} Else {
			Write-Host "No Categories selected. No Categories were exported."
		}
	} Else {
		Write-Host "Wrong export file was specified."
	}
}