﻿###########################################################################
#Created By: Vijayan Kumaran
#Date: 28th Dec 2016
#Purpose: This script will Use EWS to add Message Categories to user Exchange Mailbox
#Usage: .\Add-Categories.ps1 -Account account -Password password -Domain adatum.com -Identity Mailbox@adatum.com -Department Finance
#Notes:
# - Accounts used in this script MUST have impersonation rights to the mailbox
# - This script uses Exchange Remote Powershell to check existing Message Category in user mailbox and back them up prior toaddf new ones
# - You must install EWS API and update the DLL path in this script.
# - I only tested this script for Exchange 2010. You may test this script with Exchange 2013 and Exchange 2016. Before doing so, please change $Version variable value
###########################################################################

param(
	[parameter( Position=0, Mandatory=$true)]
		[string]$Account,
	[parameter( Position=1, Mandatory=$true)]
		[string]$Password,
	[parameter( Position=2, Mandatory=$true)]
		[string]$Domain,
        [parameter( Position=3, Mandatory=$true)]
		[string]$Identity,
        [parameter( Position=4, Mandatory=$true)]
		[string]$Department
)

#Remote Powershell... 
#Update Below Variables$Password, Domain\Account & casarray.domain.com with your own value


#***********Variables***********************
$Dir = "C:\Data\Scripts\Category"
$CASArray = "casarray.domain.com"
$EWSurl = "https://$CASArray/Exchange.asmx"
$EWSServicePath = "C:\Program Files\Microsoft\Exchange\Web Services\2.0\Microsoft.Exchange.WebServices.dll"
$Password = "Password"
$Domain = "Adatum.com"
$user = "Username"
#*******************************************

################Exchange Remote Powershell################################

Set-ExecutionPolicy Unrestricted -Scope process
$pass = convertto-securestring "P$assword" -asplaintext -force
$creds = new-object -typename System.Management.Automation.PSCredential -argumentlist "$domain\$user",$pass
$connectionUri = 'https://$CASArray/powershell/?SerializationLevel=Full'
$session = New-PSSession -configurationname microsoft.exchange -connectionuri $connectionUri -Authentication Kerberos -AllowRedirection -Credential $creds
Import-PSSession `
-Session $session `
-WarningAction SilentlyContinue `
-ErrorAction SilentlyContinue `
-DisableNameChecking `
-OutVariable $Out
$Forest = Set-ADServerSettings -ViewEntireForest $true

##########################################################################

$Date = Get-Date -Format dd-MM-yyyy

Function AddCategory()
{
#Setting up EWS URL
$Uri=[system.URI] $EWSurl
$Service.URL = $Uri
$service.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$MailboxToImpersonate)
 


$list = Import-csv "$DIR\Outlook_Categories\$Department-Categories.csv"
Foreach ($item in $list)
{
$folderid= new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Calendar,$MailboxToImpersonate)     
#Specify the Calendar folder where the FAI Item is  
$UsrConfig = [Microsoft.Exchange.WebServices.Data.UserConfiguration]::Bind($service, "CategoryList", $folderid, [Microsoft.Exchange.WebServices.Data.UserConfigurationProperties]::All)  
#Get the XML in String Format  
$XML = [System.Text.Encoding]::UTF8.GetString($UsrConfig.XmlData)  
#Deal with the first character being a Byte Order Mark  
$boMark = $XML.SubString(0,1)  
#Parse the XML  
[XML]$CatXML = $XML.SubString(1)
#Clone exiting Entry  
$NewCat = $CatXML.categories.category[0].Clone()  
#Set properties  
$NewCat.name = $item.Name
$NewCat.color =  $item.Color
$NewCat.keyboardShortcut =  $item.ShortcutKey
$NewCat.guid = "{" + [System.Guid]::NewGuid().ToString() + "}"  
#$NewCat.renameOnFirstUse = "0"  
[Void]$CatXML.categories.AppendChild($NewCat)  
$UsrConfig.XmlData = [System.Text.Encoding]::UTF8.GetBytes($boMark + $CatXML.OuterXml)  
#Update Item  
$UsrConfig.Update()  
}
}



#Web Service

Import-Module $EWSServicePath

"$(Get-Date) starts...`r`n" > $LogPath

#Creating Service Object for Exchange

$Version = "Exchange2010_SP2"
$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$Version
$Service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)
$service.Credentials = New-Object Microsoft.Exchange.WebServices.Data.WebCredentials -ArgumentList $Account,$Password,$Domain


$Mailboxes = Get-Mailbox $Identity
foreach($Mailbox in $Mailboxes)
{
$MailboxToImpersonate = $Mailbox.WindowsEmailAddress.ToString()
Write-Host "Checking Mailbox - $MailboxToImpersonate" -ForegroundColor Green

$Categories = Get-MessageCategory -mailbox $MailboxToImpersonate
If ($Categories -ne $NULL)
{
Write-Host "Categories Exist. Backing Up Current Categories"
Foreach ($Category in $Categories)
{
$name = (Get-MessageCategory $Category).name
$color = (Get-MessageCategory $Category).color

out-file -Filepath $DIR\$MailboxToImpersonate"_"$Date"_Categories.csv" -inputObject "$name,$color" -Append -Encoding UTF8

}
Write-Host "Adding $Department Categories to $MailboxToImpersonate Mailbox"
AddCategory
Write-Host "Done"
}
ELSE
{
Write-Host "No Categories Found"

Write-Host "Recreating Default Category Templates"

Set-Mailbox $mailbox -ApplyMandatoryProperties

Start-Sleep 5

Set-Mailbox $mailbox -ApplyMandatoryProperties

#Start-Sleep 120

$MailboxToImpersonate = $Mailbox.WindowsEmailAddress.ToString()
Write-Host "E-mail Checking for - $MailboxToImpersonate`r`n" -ForegroundColor Green
"Checking Message Category for mailbox - $MailboxToImpersonate`r`n" >> $LogPath

$Categories = Get-MessageCategory -mailbox $MailboxToImpersonate
If ($Categories -ne $NULL)
{
Write-Host "Categories Exist. Backing Up Current Categories"
Foreach ($Category in $Categories)
{
$name = (Get-MessageCategory $Category).name
$color = (Get-MessageCategory $Category).color

out-file -Filepath $DIR\$MailboxToImpersonate"_"$Date"_Categories.csv" -inputObject "$name,$color" -Append -Encoding UTF8
}
Write-Host "Adding $Department Categories to $MailboxToImpersonate Mailbox"
AddCategory
Write-Host "Done"
}
ELSE
{
BREAK
}
}
}

Remove-Session $Session
